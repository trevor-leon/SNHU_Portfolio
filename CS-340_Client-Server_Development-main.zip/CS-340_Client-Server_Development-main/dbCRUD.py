from pymongo import MongoClient
from bson.objectid import ObjectId

""" This module was created for the Grazioso Salvare company to allow database users
    to create, read, update, and delete data in a database from a front-end interface. """

class DatabaseCRUD(object):
    """ Create, Read, Update, and Delete operations designed for an animal shelter
    in MongoDB/PyMongo """

    def __init__(self, username: str, password: str):
        # Initialize the MongoClient.
        # This helps access the databases and collections in MongoDB.

        self.client = MongoClient('mongodb://%s:%s@localhost:54567' % (username, password))
        self.database = self.client['project']

    # Create an entry in the database given a dict of data.
    def create(self, data: dict) -> bool:
        if data is not None:
            return self.database.animals.insert_one(data) # Data is a dictionary.
        else:
            raise Exception("Nothing to save because data is empty.")

    # Read the entries of the database that match a search dict.
    def read(self, search: dict):
        if search is not None:
            return self.database.animals.find(search)
        else:
            raise Exception("Nothing to find because search is empty.")

    # Update many entries (or one) in the database that match a search dict with data in the update dict.
    def update(self, search: dict, update: dict):
        if search is not None:
            # Return the result of updating the database's search terms with the update dict.
            return self.database.animals.update_many(search, {"$set": update})
        else:
            raise Exception("Nothing to update because the search is empty.")

    # Delete an entry from the database using a search dict.
    def delete(self, search: dict):
        if search is not None:
            # To ensure nothing too destructive happens to the database, I used delete_one()
            return self.database.animals.delete_one(search)
        else:
            raise Exception("Nothing to delete because the search is empty.")