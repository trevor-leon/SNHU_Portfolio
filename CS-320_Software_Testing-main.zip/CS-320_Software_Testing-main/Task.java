package task;

public class Task {

	private String taskID;
	private String name;
	private String description;
	
	public Task(String taskID, String name, String description) {
		// set variables
		// methods verify input to find illegal arguments
		setTaskID(taskID);
		setName(name);
		setDescription(description);
	}
	
	/**
	 * @return the taskID
	 */
	public String getTaskID() {
		return taskID;
	}

	/**
	 * @param taskID the taskID to set
	 * taskID is not updatable
	 */
	private void setTaskID(String taskID){
		if(this.verifyTaskID(taskID)) {
			this.taskID = taskID;
		}
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		if(this.verifyName(name)) {
			this.name = name;
		}
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		if(this.verifyDescription(description)) { // If description passes verification
			this.description = description;
		}
	}
	
	/*
	 * @param taskID the taskID to verify
	 */
	private boolean verifyTaskID(String taskID) throws IllegalArgumentException {
		if(taskID != null && taskID.length() <= 10) {
			return true;
		} else {
			throw new IllegalArgumentException("TaskID should be 10 characters or less and not null");
		}
	}
	
	/*
	 * @param name the name to verify
	 */
	private boolean verifyName(String name) throws IllegalArgumentException {
		if(name != null && name.length() <= 20) {
			return true;
		} else {
			throw new IllegalArgumentException("Name should be 20 characters or less and not null");
		}
	}
	
	/*
	 * @param description the description to verify
	 */
	private boolean verifyDescription(String description) throws IllegalArgumentException {
		if(description != null && description.length() <= 50) {
			return true;
		} else {
			throw new IllegalArgumentException("Description should be 50 characters or less and not null");
		}
	}
	
	/*
	 * prints the task as taskID | name | description
	 */
	@Override
	public String toString() {
		return taskID + " | " + name + " | " + description + "\n";
	}
	
}
