package task;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.NoSuchElementException;

public class TaskService {

	private int tIDCount;
	private HashMap<String, Task> taskList;

	public TaskService() {
		this.tIDCount = 1;
		this.taskList = new HashMap<>();
	}

	/*
	 * @param name the name of the task to add
	 * @param description the description of the task to add
	 */
	public void addTask(String name, String description) {
		taskList.put("" + tIDCount, new Task("" + tIDCount, name, description));
		tIDCount++;
	}

	/*
	 * @param taskID the taskID of the task to get from the list
	 */
	public Task getTask(String taskID) {
		if (taskList.containsKey(taskID)) {
			return taskList.get(taskID);
		} else {
			throw new NoSuchElementException("No such task"); // else throw an exception
		}
	}

	/*
	 * @param taskID the taskID of the task to be deleted from the list
	 */
	public void deleteTask(String taskID) {
		if (taskList.containsKey(taskID)) {
			taskList.remove(taskID);
		} else {
			throw new NoSuchElementException("No such task"); // else throw an exception
		}
	}

	/*
	 * @param taskID the taskID of the task to be updated
	 * @param name the name of the task to be updated
	 * @param description the description of the task to be updated
	 */
	public Task updateTask(String taskID, String name, String description) {
		// for every task in the task list,
		if (taskList.containsKey(taskID)) {
			Task newTask = new Task(taskID, name, description);
			taskList.replace(taskID, newTask);
			return newTask;
		} else {
			throw new NoSuchElementException("No such task"); // else throw an exception
		}
	}
	
	@Override
	/*
	 * prints the list of Tasks as:
	 * --------------------------------------------------
	 * 1 | task1 | This is task one!
	 * 2 | task2 | This is task two...
	 * --------------------------------------------------
	 */
	public String toString() {
		String listString = "--------------------------------------------------\n";
		for (Entry<String, Task> entry : taskList.entrySet()) {
			listString += entry.getValue().toString();
		}
		listString += "--------------------------------------------------\n";
		return listString;
	}

}
