package contact;

import java.util.HashMap;
import java.util.Map.Entry;

public class ContactService {
	
	private int cIDCount;
	
	private HashMap<String, Contact> contactList;
	
	// Construct the ContactService for use in a program
	public ContactService() {
		
		this.cIDCount = 0;
		this.contactList = new HashMap<>();
		
	}
	
	// Add a contact to the contactList
	public void addContact(String firstName, String lastName,
			String phone, String address) {
		// Create a new contact using all of the required values
		contactList.put("" + cIDCount, new Contact("" + cIDCount, firstName, lastName, phone, address));
		cIDCount++;
	}
	
	// Remove a contact from the contactList
	public void deleteContact(String contactID) {
		
		if (contactList.containsKey(contactID)) {
			contactList.remove(contactID);
		} else {
			throw new IllegalArgumentException("Contact not found.");
		}
		
	}
	
	// Update a contact in contactList given a contactID
	public void updateContact(String contactID, Contact contact) {
		if (contactList.containsKey(contactID)) {
			contactList.put(contactID, contact);
		} else {
			throw new IllegalArgumentException("Contact not found; no updates were made.");
		}
	}
	
	@Override
	public String toString() {
		String listReturn = "";
		for (Entry<String, Contact> entry : contactList.entrySet()) {
			listReturn += entry.getValue().toString() + "\n" + "------------------------------------------------\n";
			
		}
		return listReturn;
	}
		
	
}
