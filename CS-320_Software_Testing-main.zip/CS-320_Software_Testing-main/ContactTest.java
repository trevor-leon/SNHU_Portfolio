package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import contact.Contact;

class ContactTest {
	
	Contact contact1 = new Contact("1", "Trevor", "Leon",
			"1234567890", "123 Test Rd, Mootown, PA 11111");

	@Test
	@Tag("Contact")
	void testContact() {
		//Assert that a new Contact works/looks like an established Contact
		assertEquals(new Contact("1", "Trevor", "Leon", "1234567890",
				"123 Test Rd, Mootown, PA 11111").toString(), contact1.toString());
	}

	@Test
	@Tag("ContactID")
	void testGetContactID() {
		assertEquals("1", contact1.getContactID());
	}
	
	@Test
	@Tag("ContactID")
	@DisplayName("ContactID too long")
	void testContactIDTooLongThrowsIllegalArgumentException() {
		Throwable exception = assertThrows(IllegalArgumentException.class,
				() -> new Contact("10000000000", "Trevor", "Leon",
						"1234567890", "123 Test Rd, Mootown, PA 11111"));
		assertEquals("Invalid ContactID", exception.getMessage());
	}

	@Test
	@Tag("ContactID")
	@DisplayName("ContactID null")
	void testContactIDNullThrowsIllegalArgumentException() {
		Throwable exception = assertThrows(IllegalArgumentException.class,
				() -> new Contact(null, "Trevor", "Leon",
						"1234567890", "123 Test Rd, Mootown, PA 11111"));
		assertEquals("Invalid ContactID", exception.getMessage());
	}
	
	@Test
	@Tag("firstName")
	void testGetFirstName() {
		assertEquals("Trevor", contact1.getFirstName());
	}
	
	@Test
	@Tag("firstName")
	void testSetFirstName() {
		contact1.setFirstName("Travis");
		assertEquals("Travis", contact1.getFirstName());
	}
	
	@Test
	@Tag("firstName")
	@DisplayName("firstName too long")
	void testSetFirstNameTooLongThrowsIllegalArgumentException() {
		Throwable exception = assertThrows(IllegalArgumentException.class,
				() -> contact1.setFirstName("Trevorevorevor"));
		assertEquals("Invalid First Name", exception.getMessage());
	}
	
	
	@Test
	@Tag("firstName")
	@DisplayName("firstName null")
	void testSetFirstNameNullThrowsIllegalArgumentException() {
		Throwable exception = assertThrows(IllegalArgumentException.class,
				() -> contact1.setFirstName(null));
		assertEquals("Invalid First Name", exception.getMessage());
	}

	@Test
	@Tag("lastName")
	void testGetLastName() {
		assertEquals("Leon", contact1.getLastName());
	}

	@Test
	@Tag("lastName")
	void testSetLastName() {
		contact1.setLastName("Lean");
		assertEquals("Lean", contact1.getLastName());
	}
	
	@Test
	@Tag("lastName")
	@DisplayName("lastName too long")
	void testSetLastNameTooLongThrowsIllegalArgumentException() {
		Throwable exception = assertThrows(IllegalArgumentException.class,
				() -> contact1.setLastName("Leoneoneoneon"));
		assertEquals("Invalid Last Name", exception.getMessage());
	}
	
	
	@Test
	@Tag("lastName")
	@DisplayName("lastName null")
	void testSetLastNameNullThrowsIllegalArgumentException() {
		Throwable exception = assertThrows(IllegalArgumentException.class,
				() -> contact1.setLastName(null));
		assertEquals("Invalid Last Name", exception.getMessage());
	}

	@Test
	@Tag("Phone")
	void testGetPhone() {
		assertEquals("1234567890", contact1.getPhone());
	}

	@Test
	@Tag("Phone")
	void testSetPhone() {
		contact1.setPhone("0987654321");
		assertEquals("0987654321", contact1.getPhone());
	}
	
	@Test
	@Tag("Phone")
	@DisplayName("Phone too long")
	void testSetPhoneTooLongThrowsIllegalArgumentException() {
		Throwable exception = assertThrows(IllegalArgumentException.class,
				() -> contact1.setPhone("123-456-7890"));
		assertEquals("Invalid Phone Number", exception.getMessage());
	}
	
	
	@Test
	@Tag("Phone")
	@DisplayName("Phone null")
	void testSetPhoneNullThrowsIllegalArgumentException() {
		Throwable exception = assertThrows(IllegalArgumentException.class,
				() -> contact1.setPhone(null));
		assertEquals("Invalid Phone Number", exception.getMessage());
	}

	@Test
	@Tag("Address")
	void testGetAddress() {
		assertEquals("123 Test Rd, Mootown, PA 11111", contact1.getAddress());
	}

	@Test
	@Tag("Address")
	void testSetAddress() {
		contact1.setAddress("11 Short Rd, Small, PA 10001");
		assertEquals("11 Short Rd, Small, PA 10001", contact1.getAddress());
	}
	
	@Test
	@Tag("Address")
	@DisplayName("Address too long")
	void testSetAddressTooLongThrowsIllegalArgumentException() {
		Throwable exception = assertThrows(IllegalArgumentException.class,
				() -> contact1.setAddress("12345 Long Road, Moontown, PA 11111"));
		assertEquals("Invalid Address", exception.getMessage());
	}
	
	
	@Test
	@Tag("Address")
	@DisplayName("Address null")
	void testSetAddressNullThrowsIllegalArgumentException() {
		Throwable exception = assertThrows(IllegalArgumentException.class,
				() -> contact1.setAddress(null));
		assertEquals("Invalid Address", exception.getMessage());
	}

}
