package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import contact.Contact;
import contact.ContactService;

class ContactServiceTest {
	
	ContactService cs;
	
	@BeforeEach
	void setUp() throws Exception {
		cs = new ContactService();
		cs.addContact("Trev", "Leon", "1234567890", "123 Rand Rd.");
	}

	@Test
	@Tag("Add")
	@DisplayName("Add Contact")
	void testAddContact() {
		assertDoesNotThrow(() -> {cs.addContact("Trevor", "Leon", "0987654321", "321 Rand Rd.");});
	}

	@Test
	@Tag("Delete")
	@DisplayName("Delete Contact")
	void testDeleteContact() {
		// Add a contact to cs, and then delete it. Assert that cs's list is empty
		assertDoesNotThrow(() -> {cs.deleteContact("0");});
	}
	
	@Test
	@Tag("Delete")
	@DisplayName("Delete Contact DNE")
	void testDeleteContactNotInList() { // What if contact isn't in the list?
		assertThrows(IllegalArgumentException.class, () -> {cs.deleteContact("64");});
	}

	@Test
	@Tag("Update")
	@DisplayName("Contact Updated")
	void testUpdateContactUpdated() {
		// create a new contact and update the original
		Contact contact1 = new Contact("0", "Trev", "Leon", "0987654321", "456 Magic St.");
		cs.updateContact("0", contact1);
		
		// Make sure the original contact's toString has changed:
		assertNotEquals("0 | Trev | Leon | 1234567890 | 123 Rand Rd.", cs.toString());
	}
	
	@Test
	@Tag("Update")
	@DisplayName("Contact Not Updated")
	void testUpdateContactNotInList() {	
		// Make a new contact with an index not in the list.
		Contact contact1 = new Contact("10", "Trev", "Leon", "0987654321", "456 Magic St.");
		
		assertThrows(IllegalArgumentException.class,
				() -> {cs.updateContact("64", contact1);});
	}
	
	@Test
	@Tag("toString")
	@DisplayName("Testing toString()")
	void testToString() {
		cs.addContact("Zak", "Kauff", "1112223333", "123 Rand Rd.");
		// System.out.println(cs.toString());
		
		// Make sure desired output = the output
		assertEquals("0 | Trev | Leon | 1234567890 | 123 Rand Rd.\n"
				+ "------------------------------------------------\n"
				+ "1 | Zak | Kauff | 1112223333 | 123 Rand Rd.\n"
				+ "------------------------------------------------\n",
				cs.toString());
	}

}
