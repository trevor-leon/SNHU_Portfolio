package test;

import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import task.Task;

class TaskTest {
	
	Task task1;

	@BeforeEach
	void setUpTask() { // set up a valid Task
		task1 = new Task("1234567890", "New Task 01", "This is a new Task!");
	}
	

	@Test
	@Tag("Task")
	@DisplayName("Task creation and getters")
	void testTaskCreation() { //also tests Task's getters
		assertAll("Task Constructor",
				() -> assertEquals("1234567890", task1.getTaskID()),
				() -> assertEquals("New Task 01", task1.getName()),
				() -> assertEquals("This is a new Task!", task1.getDescription()));
	}
	
	@Test
	@Tag("setTaskID")
	@DisplayName("Task ID null in Task constructor")
	void testSetTaskIDNull() {
		Throwable exception = assertThrows(IllegalArgumentException.class,
				() -> {new Task(null, "Null", "Null description");});
		
		assertEquals("TaskID should be 10 characters or less and not null", exception.getMessage());
	}
	
	@Test
	@Tag("setTaskID")
	@DisplayName("Task ID too long in Task constructor")
	void testSetTaskIDTooLong() {
		Throwable exception = assertThrows(IllegalArgumentException.class,
				() -> {new Task("11 Characters+", "ID2long", "ID is too long");});
		
		assertEquals("TaskID should be 10 characters or less and not null", exception.getMessage());
	}

	@Test
	@Tag("setName")
	@DisplayName("setName(null)")
	void testSetNameNull() { // Asserts that setName() throws an exception when passed null
		Throwable exception = assertThrows(IllegalArgumentException.class,
				() -> {task1.setName(null);});
		assertEquals("Name should be 20 characters or less and not null",
				exception.getMessage());
	}
	
	@Test
	@Tag("setName")
	@DisplayName("setName(too long)")
	void testSetNameTooLong() { // Asserts that setName() throws an exception when passed null
		Throwable exception = assertThrows(IllegalArgumentException.class,
				() -> {task1.setName("Task with a Name of 20+ Characters");});
		assertEquals("Name should be 20 characters or less and not null",
				exception.getMessage());
	}

	@Test
	@Tag("setDescription")
	@DisplayName("valid setDiscription()")
	void testSetDescription() {
		task1.setDescription("This is a new description");
		assertEquals("This is a new description", task1.getDescription());
	}
	
	@Test
	@Tag("setDescription")
	@DisplayName("setDiscription(null)")
	void testSetDescriptionNull() { // Asserts that setName() throws an exception when passed null
		Throwable exception = assertThrows(IllegalArgumentException.class,
				() -> {task1.setDescription(null);});
		assertEquals("Description should be 50 characters or less and not null",
				exception.getMessage());
	}
	
	@Test
	@Tag("setDescription")
	@DisplayName("setDiscription(too long)")
	void testSetDescriptionTooLong() { // Asserts that setName() throws an exception when passed null
		Throwable exception = assertThrows(IllegalArgumentException.class,
				() -> {task1.setDescription("123456789012345678901234567890123456789012345678901");});
		assertEquals("Description should be 50 characters or less and not null",
				exception.getMessage());
	}
	
	@Test
	@Tag("toString")
	@DisplayName("Test toString()")
	void testToString() {
		Task task2 = new Task("2222222", "Task Two", "Second Description");
		String toStringMessage = task1.toString() + task2.toString();
		assertEquals("1234567890 | New Task 01 | This is a new Task!\n"
				+ "2222222 | Task Two | Second Description\n", toStringMessage);
	}

}
