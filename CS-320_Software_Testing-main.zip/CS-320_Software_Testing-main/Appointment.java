/*
 * Stores an appointment's data:
 * an apptID supplied by a Service
 * an apptDate is the date of the appointment
 * a description of what the appointment is for
 * 
 * author: Trevor Leon
 */
package appt;

import java.time.LocalDate; // Special thanks to: https://www.youtube.com/watch?v=0XgdX5hDL4U
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Appointment {
	
	private String apptID; // non-updatable apptID
	private LocalDate apptDate; // date of appt
	private String description; // desc of appt
	
	/*
	 * Construct an Appointment
	 */
	public Appointment(String apptID, LocalDate apptDate, String description) {
		
		this.setApptID(apptID);
		this.setApptDate(apptDate);
		this.setDescription(description);
		
	}
	
	/**
	 * @return the apptID
	 */
	public String getApptID() {
		return apptID;
	}
	
	/**
	 * @return the apptDate
	 */
	public LocalDate getApptDate() {
		return apptDate;
	}
	
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param apptDate the apptDate to set
	 */
	private void setApptID(String apptID) {
		// if apptID is blank, null, greater than 10 characters, or contains special characters...
		apptID = Objects.requireNonNull(apptID, "Appointment ID cannot be null"); // inspired by code in the LocalDate class
		// Pattern and Matcher help from:
		// https://docs.oracle.com/javase/7/docs/api/java/util/regex/Pattern.html
		// https://www.geeksforgeeks.org/java-program-to-check-whether-the-string-consists-of-special-characters/
		Pattern p = Pattern.compile("[^a-z0-9]", Pattern.CASE_INSENSITIVE);
		// ^ means not; a-z characters (lowercase) + 0-9 digits; case insensitive
		Matcher m = p.matcher(apptID); // match pattern to apptID
		if (apptID.equals("") || apptID.length() > 10 || m.find()) { // blank, too long, or pattern found...
			throw new IllegalArgumentException("Appointment ID cannot be blank, null, length greater than ten, or contain special characters");
		} else {
			this.apptID = apptID;
		}
	}
	
	/**
	 * @param apptDate the apptDate to set
	 */
	public void setApptDate(LocalDate apptDate) {
		// if the String format of apptDate is null, or before the present...
		apptDate = Objects.requireNonNull(apptDate, "Appointment date cannot be null");
		if (apptDate.isBefore(LocalDate.now())) {
			throw new IllegalArgumentException("Appointment Date cannot be past or too far into the future");
		} else {
			this.apptDate = apptDate;
		}
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		description = Objects.requireNonNull(description, "Description cannot be null");
		// if the description is blank, null, or longer than 50 characters...
		Pattern p = Pattern.compile("[^a-z0-9 ]", Pattern.CASE_INSENSITIVE); // create a pattern based on desired chars
		// ^ means not; a-z characters (lowercase) + 0-9 digits; case insensitive
		Matcher m = p.matcher(description); // match pattern to description
		if (description.equals("") || description.length() > 50 || m.find()) { //blank, too long, or pattern found...
			throw new IllegalArgumentException("Appointment Description cannot be blank, greater than 50 chars in length, or contain special chars.");
		} else {
			this.description = description;
		}
	}

	@Override
	public String toString() {
		return "[apptID= " + apptID + ", apptDate= " + apptDate + ", description= " + description + "]";
	}
	
	
	
}
