package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.NoSuchElementException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import task.Task;
import task.TaskService;

class TaskServiceTest {

	private TaskService ts;

	@BeforeEach
	void setUp() throws Exception {
		ts = new TaskService();
		ts.addTask("task1", "This is task one!");
		ts.addTask("task2", "This is task two...");
	}

	@Test
	@Tag("addTask")
	void testAddTaskException() {
		assertAll("addTask", () -> assertThrows(IllegalArgumentException.class,
				() -> {ts.addTask("this name is way too extremely long", "This desc is fine");}),
				() -> assertThrows(IllegalArgumentException.class,
						() -> {ts.addTask("This name is fine",  "This desc is too long" +
								"1111111111111111111111111111111111111111111111111111111111111111111111111");}));
	}

	@Test
	@Tag("addTask")
	void testGetTask() {
		Task task2 = ts.getTask("2");

		//assert every value is correctly gotten from the getter
		assertAll("getTask()",
				() -> {assertEquals("2", task2.getTaskID());},
				() -> {assertEquals("task2", task2.getName());},
				() -> {assertEquals("This is task two...", task2.getDescription());});
	}

	@Test
	@Tag("getTask")
	void testGetTaskException() {
		// assert that getTask() throws an exception if the input is out of bounds
		assertThrows(NoSuchElementException.class,
				() -> {ts.getTask("100");}); 
	}

	@Test
	@Tag("deleteTask")
	void testDeleteTask() {
		// delete the tasks first
		ts.deleteTask("1");
		ts.deleteTask("2");

		// assert that the tasks have been deleted
		assertAll("deleteTask", () -> assertThrows(NoSuchElementException.class,
				() -> {ts.deleteTask("1");}),
				() -> assertThrows(NoSuchElementException.class,
						() -> {ts.deleteTask("2");}));
	}

	@Test
	@Tag("deleteTask")
	void testDeleteTaskException() {
		// assert that deleteTask() throws an exception if the input is out of bounds
		assertThrows(NoSuchElementException.class,
				() -> {ts.deleteTask("100");});
	}

	@Test
	@Tag("updateTask")
	void testUpdateTask() {
		ts.updateTask("1", "New Name", "New Desc");

		// assert that the task has been updated
		assertAll("updateTask",
				() -> {assertEquals("1", ts.getTask("1").getTaskID());},
				() ->  {assertEquals("New Name", ts.getTask("1").getName());},
				() -> {assertEquals("New Desc", ts.getTask("1").getDescription());});
	}

	@Test
	@Tag("updateTask")
	void testUpdateTaskException() {
		// assert updateTask(ID) throws an exception if ID is out of bounds
		assertThrows(NoSuchElementException.class,
				() -> {ts.updateTask("12", "Nope", "No way");});
	}

	@Test
	@Tag("toString")
	void testToString() {
		System.out.println(ts.toString());
		assertEquals("--------------------------------------------------\n"
				+ "1 | task1 | This is task one!\n"
				+ "2 | task2 | This is task two...\n"
				+ "--------------------------------------------------\n", ts.toString());

	}

}
