package test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
//import java.time.Year;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import appt.Appointment;

class AppointmentTest {
	
	Appointment appointment;

	@BeforeEach
	void setUp() throws Exception {
		// create an appointment for the tests to use
		appointment = new Appointment("1", LocalDate.now(), "desc");
	}

	@Test
	void testAppointment() { // tests the appointment constructor and toString at the same time
		assertEquals("[apptID= 1, apptDate= " + LocalDate.now() + ", description= desc]", appointment.toString());
	}

	@Test
	void testGetApptID() {
		assertEquals("1", appointment.getApptID());
	}

	@Test
	void testGetApptDate() {
		assertEquals(LocalDate.now(), appointment.getApptDate());
	}

	@Test
	void testGetDescription() {
		assertEquals("desc", appointment.getDescription());
	}
	
	@Test
	@Tag("apptID")
	void testSetApptIDNull() {
		Throwable exception = assertThrows(NullPointerException.class,
				() -> {new Appointment(null, LocalDate.now(), "null ID");}); //task failed successfully
		assertEquals("Appointment ID cannot be null", exception.getMessage());
	}
	
	@Test
	@Tag("apptID")
	void testSetApptIDBlank() {
		Throwable exception = assertThrows(IllegalArgumentException.class,
				() -> {new Appointment("", LocalDate.now(), "ID blank");});
		assertEquals("Appointment ID cannot be blank, null, length greater than ten, or contain special characters", exception.getMessage());
	}
	
	@Test
	@Tag("apptID")
	void testSetApptIDTooLong() {
		Throwable exception = assertThrows(IllegalArgumentException.class,
				() -> {new Appointment("1111111111" + "1111111111" + "1", LocalDate.now(), "ID too long");});
		assertEquals("Appointment ID cannot be blank, null, length greater than ten, or contain special characters", exception.getMessage());
	}
	
	@Test
	@Tag("apptID")
	void testSetApptIDSpecialChars() {
		Throwable exception = assertThrows(IllegalArgumentException.class,
				() -> {new Appointment("What?!@#", LocalDate.now(), "ID special chars");});
		assertEquals("Appointment ID cannot be blank, null, length greater than ten, or contain special characters", exception.getMessage());
	}

	@Test
	@Tag("apptDate")
	void testSetApptDate() {
		appointment.setApptDate(LocalDate.now());
		assertEquals(LocalDate.now().toString(), appointment.getApptDate().toString());
	}
	
	@Test
	@Tag("apptDate")
	void testSetApptDatePast() {
		Throwable exception = assertThrows(IllegalArgumentException.class,
				() -> {appointment.setApptDate(LocalDate.of(2022, 2, 1));});
		assertEquals("Appointment Date cannot be past or too far into the future",
				exception.getMessage());
	}

	@Test
	@Tag("setDescription")
	void testSetDescription() {
		appointment.setDescription("This is a new description");
		assertEquals("This is a new description", appointment.getDescription());
	}
	
	@Test
	@Tag("setDescription")
	void testSetDescriptionNull() {
		Throwable exception = assertThrows(NullPointerException.class,
				() -> {appointment.setDescription(null);});
		assertEquals("Description cannot be null",
				exception.getMessage());
	}
	
	@Test
	@Tag("setDescription")
	void testSetDescriptionBlank() {
		Throwable exception = assertThrows(IllegalArgumentException.class,
				() -> {appointment.setDescription("");});
		assertEquals("Appointment Description cannot be blank, greater than 50 chars in length, or contain special chars.",
				exception.getMessage());
	}
	
	@Test
	@Tag("setDescription")
	void testSetDescriptionTooLong() {
		Throwable exception = assertThrows(IllegalArgumentException.class,
				() -> {appointment.setDescription("1111111111" + "1111111111" + "1111111111"
		+ "1111111111" + "1111111111" + "1");});
		assertEquals("Appointment Description cannot be blank, greater than 50 chars in length, or contain special chars.",
				exception.getMessage());
	}
	
	@Test
	@Tag("setDescription")
	void testSetDescriptionSpecialChars() {
		Throwable exception = assertThrows(IllegalArgumentException.class,
				() -> {appointment.setDescription("!@#$%^&*()");});
		assertEquals("Appointment Description cannot be blank, greater than 50 chars in length, or contain special chars.",
				exception.getMessage());
	}

}
