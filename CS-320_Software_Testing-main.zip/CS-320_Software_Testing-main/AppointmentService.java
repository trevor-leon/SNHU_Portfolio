/*
 * Creates a HashMap to store Appointments in a list
 * implements an add method to add appointments to the list
 * implements a delete method to delete appointments in the list
 * 
 * Author: Trevor Leon
 */
package appt;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class AppointmentService {
	
	//the count of the ID
	private Integer idCount;
	
	// Very special thanks to Bro Code on YouTube for HashMap help and more
	private HashMap<String, Appointment> apptMap;
	
	public AppointmentService() {
		// initialize the idCount and HashMap
		idCount = 1;
		apptMap = new HashMap<>();
	}
	
	/*
	 * Add an appointment to the HashMap
	 */
	public void addAppointment(LocalDate date, String description) {
		Appointment newAppointment = new Appointment(idCount.toString(), date, description);
		newAppointment = Objects.requireNonNull(newAppointment); // make sure  appt is not null
		apptMap.put(idCount.toString(), newAppointment); // put a new appt into the list using the current idCount
		idCount++; //increment idCount
	}
	
	/*
	 * Delete an appointment from the HashMap using an index Integer
	 */
	public void deleteAppointment(String key) {
		if (apptMap.containsKey(key)) {
			apptMap.remove(key);
		} else {
			throw new IllegalArgumentException("Appointment does not exist");
		}
	}

	@Override
	public String toString() {
		String toString = "";
		for (Map.Entry<String, Appointment> entry : apptMap.entrySet()) {
			toString += "[" + entry.getKey() + " - " + entry.getValue() + "]\n";
		}
		return toString;
	}
	
	
}
