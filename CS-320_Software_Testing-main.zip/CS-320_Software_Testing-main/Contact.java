package contact;

public class Contact {
	
	private String contactID;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;
	
	public Contact(String contactID, String firstName, String lastName,
			String phone, String address) {
		// Sanitize the code: make sure the fields are not null and within character range
		if(contactID == null || contactID.length() > 10) {
			throw new IllegalArgumentException("Invalid ContactID");
		}
		// Set the values if no IllegalArgumentExceptions have been thrown.
		this.contactID = contactID;
		this.setFirstName(firstName);
		this.setLastName(lastName);
		this.setPhone(phone);
		this.setAddress(address);
	}

	// return contactID
	public String getContactID() {
		return contactID;
	}

	// set contactID not available as per requirements
	 

	// return firstName
	public String getFirstName() {
		return firstName;
	}

	// set firstName
	public void setFirstName(String firstName) {
		if(firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid First Name");
		} else {
		    this.firstName = firstName;
		}
	}

	// return lastName
	public String getLastName() {
		return lastName;
	}

	// set lastName
	public void setLastName(String lastName) {
		if(lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Invalid Last Name");
		} else {
		    this.lastName = lastName;
		}
	}

	// return phone
	public String getPhone() {
		return phone;
	}

	// set phone
	public void setPhone(String phone) {
		if(phone == null || phone.length() > 10) {
			throw new IllegalArgumentException("Invalid Phone Number");
		} else {
		    this.phone = phone;
		}
	}

	// return address
	public String getAddress() {
		return address;
	}
	
	// set address
	public void setAddress(String address) {
		if(address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid Address");
		} else {
		    this.address = address;
		}
	}
	
	@Override
	public String toString() {
		return this.getContactID() + " | " + this.getFirstName() + " | " +
	this.getLastName() + " | " + this.getPhone() + " | " + this.getAddress();
	}
	
}
