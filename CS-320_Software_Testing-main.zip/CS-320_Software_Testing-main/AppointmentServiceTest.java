package test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import appt.AppointmentService;

class AppointmentServiceTest {
	AppointmentService as;

	@BeforeEach
	void setUp() throws Exception {
		as = new AppointmentService();
		as.addAppointment(LocalDate.now(), "appointment one description");
	}

	@Test
	@Tag("AppointmentService")
	void testAppointmentService() {
		assertEquals("[1 - [apptID= 1, apptDate= " + LocalDate.now() + ", description= appointment one description]]\n", as.toString()); //compiles, meaning object exists
	}

	@Test
	@Tag("addAppointment")
	void testAddAppointment() {
		as.addAppointment(LocalDate.now(), "appointment two today");
		assertEquals("[1 - [apptID= 1, apptDate= " + LocalDate.now() + ", description= appointment one description]]\n"
		+ "[2 - [apptID= 2, apptDate= " + LocalDate.now() + ", description= appointment two today]]\n", as.toString());
	}

	@Test
	@Tag("deleteAppointment")
	void testDeleteAppointment() {
		as.deleteAppointment("1");
		assertEquals("", as.toString());;
	}
	
	@Test
	@Tag("deleteAppointment")
	void testDeleteAppointmentException() {
		assertThrows(IllegalArgumentException.class,
				() -> as.deleteAppointment("64"));
	}

}
