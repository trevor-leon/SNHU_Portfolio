# CS-320_Software_Testing

**How can I ensure that my code, program, or software is functional and secure?**
    
   Ensuring that code is functional and secure is accomplished by writing tests for the code. Tests prove that a function of a program works correctly and does what should be done. Testing for failing conditions ensures that improper input is handled correctly.
    
**How do I interpret user needs and incorporate them into a program?**

   Listening and understanding exactly what needs to be done is key to designing quality software. Understanding the specific user needs and how they translate into variables and methods is the first step to developing software. If the requirements of the project aren't explicitly stated, the team members might have different visions of the final product in mind.
    
**How do I approach designing software?**

   The key to designing software is to stick to the project requirements. If the requirements state that a variable is needed, then the variable should be included in the final product. If a method is not a helper method nor required by the requirements, then it shouldn't be included in the final product. Any additional code that isn't absolutely necessary won't fit into the requirements, and it too will need tested. Additionally, other people looking at the code might not understand the point of the code since it wasn't in the requirements.

**Thanks for the help, Mr. K.!**

-Trev
