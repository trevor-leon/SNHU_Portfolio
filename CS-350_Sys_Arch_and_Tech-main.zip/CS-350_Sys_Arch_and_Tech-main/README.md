# CS-350_Sys_Arch_and_Tech

Final Project Reflection

The thermostat program for an imaginary company, SysTec, was designed to keep track of the set temperature; read the temperature; and turn the heater (LED) on when the set temperature value was greater than the read temperature in the room.

While preparing to complete the thermostat program, I learned that time management is paramount when it comes to programming. Due to family emergencies, I couldn’t set enough usable time aside to get the program to run properly. Because of this, the LED doesn’t turn on whether the setTemperature value is higher than the read temperature or not. This leads me to believe that the program was getting stuck at some point because code within my state machines wasn’t being reached, and the superloop or the !TimerFlag loop didn’t continue to iterate. I even tried to test the values of the thermostat variables using the DISPLAY(x) function. I managed to get the values written once, but the setTemp variable doesn’t update with the button presses. Otherwise, I believe my code to be mostly finished. It’s possible I’m simply missing a line or two of code; causing the program to not operate.

The flow of the project was fairly simple, and the superloop didn’t even require much code because the functionality happened within the timer callback function. After initializing the GPIO, UART, I2C, and Timer, I set up the task structure variables so that they functioned how I wanted them to. From there, the program enters the superloop, and waits for the TimerFlag to be set by the timer callback. The callback itself contains the task scheduler which will call the appropriate task tick function when it’s time to do so and set the state to the state the function returns. Unfortunately, somewhere along the line, things got jammed up and are not running correctly.

On the upside, my code is well-documented and my variables' purpose are clear for future developers. I usually tried to employ the use of named variables rather than stray numbers/constants for readability and ease of maintenance.
