# CS-250-Q1510
Software Development Lifecycle

In the software development lifecycle, user needs are determined and translated into user stories for the development teams to fulfill. User stories are essentially first-hand accounts of what a user(s) needs. This allows the developers to put themselves in the user's shoes and create code to allow the user story to become a reality.
After taking this course, I will definitely take more time to plan out my programs and decide everything that I need up front rather than as I build the program. It also would help to take a step back once in a while and as myself if I'm on the right track; basically giving myself a Scrum meeting.
Lastly, I think a good team member in software development should get their end of the work done. If they can't, they should ask for help. The entire project depends on workers meeting goals, otherwise the whole project might fall apart.
